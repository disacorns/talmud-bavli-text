

The Bavli

This is a complete copy of The Bavli according the Vilna edition at

http://www.mechon-mamre.org/b/l/l0.htm

(c) 2002 all rights reserved to Mechon Mamre, 12 Hayyim Vital,
Jerusalem, Israel mtr@mechon-mamre.org for this HTML version.

You may use this material only for your private study, not for
publishing in any form, including any Web site.  Under the Fair Use
Doctrine, you may use short quotations from it in any other work,
including copyrighted publications.  Any other use requires written
permission from us.

Links going outside this set of texts go to the Web site.

The zip ordinarily unzips into a folder named b\l ; to use this HTML
collection, open l0.htm in this b\l folder.

Last updated:  21 May 2014

